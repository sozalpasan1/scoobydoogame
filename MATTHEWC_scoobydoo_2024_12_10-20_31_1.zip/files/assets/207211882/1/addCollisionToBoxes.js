var AddCollisionToboxes = pc.createScript('addCollisionToboxes');

// initialize code called once per entity
AddCollisionToboxes.prototype.initialize = function() {

};

// update code called every frame
AddCollisionToboxes.prototype.update = function(dt) {

};

// uncomment the swap method to enable hot-reloading for this script
// update the method body to copy state from the old instance
// AddCollisionToboxes.prototype.swap = function(old) { };

// learn more about scripting here:
// https://developer.playcanvas.com/user-manual/scripting/