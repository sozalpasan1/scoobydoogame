window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "2131347.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'deviceTypes': [`webgl2`, `webgl1`],
    'powerPreference': "default"
};
window.SCRIPTS = [ 207214495, 206877091, 206877093, 206877095, 206877089, 206877109, 206884570, 206885048, 207211882 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/206877092/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/206877295/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/206877104/1/ammo.js', 'preload' : true},
];
